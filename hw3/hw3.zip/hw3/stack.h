//
//  stack.h
//  hw3
//
//  Created by Thomas Hocking on 2/19/14.
//  Copyright (c) 2014 Thomas Hocking. All rights reserved.
//

#ifndef hw3_stack_h
#define hw3_stack_h



#endif
